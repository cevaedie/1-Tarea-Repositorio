const loginButton = document.getElementById("loginButton");
const loginFormContainer = document.getElementById("loginFormContainer");

loginButton.addEventListener("click", () => {
  loginFormContainer.classList.toggle("hidden");
  setTimeout(() => {
    loginFormContainer.style.right = "0%"; // Movemos el formulario al centro
  }, 0.5); // 1000 milisegundos (1 segundo) de retraso antes de mostrar el formulario
});


