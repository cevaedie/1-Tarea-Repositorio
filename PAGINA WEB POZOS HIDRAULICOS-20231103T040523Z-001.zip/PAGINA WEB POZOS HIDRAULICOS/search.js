var searchResults = [
  // Simulación de resultados de búsqueda (puedes agregar más datos)
  {
    titulo: "Pozos hidraulicos",
    descripcion: "Pozos hidraulicos.",
    url: "formulario.html",
  },
  
];

function toggleSearchInput() {
  var searchInputContainer = document.getElementById("searchInputContainer");
  var searchBtn = document.getElementById("search-btn");

  if (searchInputContainer.style.display === "flex") {
    searchInputContainer.style.display = "none";
    searchBtn.style.display = "block";
  } else {
    searchInputContainer.style.display = "flex";
    searchBtn.style.display = "none";
  }
}

function performSearch() {
  var searchTerm = document.getElementById("searchInput").value;

  var searchResultsContainer = document.getElementById(
    "searchResultsContainer"
  );

  // Limpiar el contenedor antes de agregar nuevos resultados
  searchResultsContainer.innerHTML = "";

  if (searchTerm.trim() !== "") {
    for (var i = 0; i < searchResults.length; i++) {
      var result = searchResults[i];
      var resultItem = document.createElement("div");
      resultItem.innerHTML = `
                        <a href="${result.url}">
                            <h3>${result.titulo}</h3>
                            <p>${result.descripcion}</p>
                        </a>
                        <hr>
                    `;
      searchResultsContainer.appendChild(resultItem);
    }

    // Mostrar el contenedor de resultados de búsqueda
    searchResultsContainer.style.display = "block";
  } else {
    // Ocultar el contenedor de resultados de búsqueda si no hay término de búsqueda
    searchResultsContainer.style.display = "none";
  }
}
