const buttons = document.querySelectorAll(".menu-button");
const darkBackground = document.getElementById("darkBg");

buttons.forEach((button) => {
  button.addEventListener("click", () => {
    const target = button.dataset.target;
    const menuText = document.getElementById(target);
    const isVisible = menuText.classList.contains("show");

    // Ocultar todos los textos
    document.querySelectorAll(".menu-text").forEach((text) => {
      text.classList.remove("show");
    });

    if (!isVisible) {
      menuText.classList.add("show"); // Mostrar el texto
      darkBackground.style.display = "block"; // Mostrar el fondo oscuro
    } else {
      darkBackground.style.display = "none"; // Ocultar el fondo oscuro 
    }
  });
});

